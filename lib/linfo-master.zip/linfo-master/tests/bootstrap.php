<?php

define('LINFO_TESTING', 1);
define('LINFO_TESTDIR', dirname(__FILE__));

require_once dirname(dirname(__FILE__)).'/standalone_autoload.php';
