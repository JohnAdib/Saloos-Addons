<?php

return require dirname(dirname(__FILE__)).'/src/Linfo/Lang/en.php';
