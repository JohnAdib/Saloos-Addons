<?php

$var = 'foo';
